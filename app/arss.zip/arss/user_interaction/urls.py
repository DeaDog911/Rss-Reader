from django.urls import path, include

from . import views

app_name = 'user_interaction'

urlpatterns = [
    path('', views.ProfileView.as_view(), name='profile_url'),
    # path('', include('django.contrib.auth.urls')),
    path('delete_feed', views.delete_feed, name='delete_feed_url'),
    path('edit_feed', views.edit_feed, name='edit_feed_url'),
    path('registration', views.RegisterFormView.as_view(), name='registration_url'),
    path('edit', views.edit_profile, name='edit_profile_url'),
    # path('send_message', views.send_message, name='send_message_url'),
]