from django.apps import AppConfig


class UserInteractionConfig(AppConfig):
    name = 'user_interaction'
