import requests
from django.shortcuts import render
from django.http import HttpResponse, Http404, JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.generic.edit import FormView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.hashers import check_password
from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin

from rss_reader import models
from . import forms


class ProfileView(LoginRequiredMixin, ListView):
    model = models.Feed
    template_name = 'user_interaction/profile.html'

    login_url = 'login/'
    redirect_field_name = 'redirect_to'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        context.update({
            'is_paginated': False,
        })

        return context

    def request_to_feedly(self, query):
        return requests.get('https://sandbox.feedly.com/v3/search/feeds', {'query': query})

    def post(self, request):
        global response
        if self.request.is_ajax():
            data = self.request.POST
            user_request = data.get('user_request')
            # if it's link it would try to save a feed

            if '://' in user_request:
                try:
                    feed = models.Feed(link=user_request, user=request.user)
                    feed.save()
                    return HttpResponse('')
                # if it's bad link it would try to find this feed by feedly
                except KeyError:
                    if not data.get('add'):
                        response = self.request_to_feedly(user_request)
            else:
                # if it's not a link it would try to find this feed by feedly
                response = self.request_to_feedly(user_request)
            return JsonResponse(response.json())


def delete_feed(request):
    if request.is_ajax():
        data = request.POST
        link = data.get('feed')
        feed = models.Feed.objects.get(link=link)
        feed.delete()
        return HttpResponse('')
    else:
        raise Http404


def edit_feed(request):
    if request.is_ajax():
        data = request.POST
        new_name = data.get('new_name')
        new_link = data.get('new_link')
        old_link = data.get('old_link')
        feed = models.Feed.objects.get(link=old_link)
        feed.link = new_link
        feed.title = new_name
        feed.save()
        return HttpResponse('')


class RegisterFormView(FormView):
    form_class = UserCreationForm
    success_url = "/login/"
    template_name = "user_interaction/registration.html"

    def form_valid(self, form):
        form.save()
        return super(RegisterFormView, self).form_valid(form)


@login_required
def edit_profile(request):
    if request.is_ajax():
        data = request.POST
        if check_password(data.get('password'), request.user.password):
            user = request.user
            user.username = data.get('new_username')
            user.email = data.get('new_email')
            user.save()
            return HttpResponse('')
        else:
            return HttpResponse('Invalid password')
    else:
        return render(request, 'user_interaction/edit_profile.html', context={})


def add_feed(request):
    if request.is_ajax():
        data = request.POST
        link = data.get('add_feed_link')
        new_feed = models.Feed(link=link, user=request.user)
        try:
            new_feed.save()
        except KeyError:
            return render(request, 'errors/wrong_link.html', context={})
        return HttpResponse('')

# def send_message(request):
#     if request.is_ajax():
#         data = request.POST
#         username = request.user.get_username()
#         user_email = data.get('email')
#         subject = data.get('subject')
#         user_message = data.get('message')
#         admin_email = 'deadog911@gmail.com'
#         message = f'username: {username}\nemail: {user_email}\nmessage: {user_message}'
#         if subject and message:
#             try:
#                 send_mail(subject, message, admin_email, [admin_email], fail_silently=False)
#             except BadHeaderError:
#                 return HttpResponse('Invalid header found.')
#             return HttpResponse('')
#         else:
#             # In reality we'd use a form class
#             # to get proper validation errors.
#             return HttpResponse('Make sure all fields are entered and valid.')
#     else: 
#         raise Http404
