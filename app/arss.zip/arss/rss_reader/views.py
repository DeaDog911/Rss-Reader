from django.shortcuts import render, redirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin

from . import models
from . import util


class FeedListView(LoginRequiredMixin, ListView):
    model = models.Feed
    template_name = "rss_reader/index.html"

    login_url = '../profile/login/'
    redirect_field_name = 'redirect_to'

    search_query = ''

    def query_in_entry(self, entry):
        if self.search_query in entry['title'] or self.search_query in entry['description']:
            print(self.search_query)
            return 1
        else:
            return 0

    # @login_required
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        ufeed = None
        is_new = True
        feed_title = self.request.GET.get('feed', 'new')
        if feed_title == '':
            feed_title = 'new'

        ufeed_entries = None

        if feed_title == 'new':
            ufeed = util.get_new_entries()
            ufeed_entries = ufeed
        else:
            for feed in self.request.user.feeds.iterator():
                if feed.title == feed_title:
                    ufeed = feed
                    ufeed_entries = util.parse_feed(feed.link).entries
                    for entry in ufeed_entries:
                        entry.update({'description_without_html': util.remove_html(entry.description)})
                    is_new = False

        self.search_query = self.request.GET.get('search', '')

        if self.search_query:
            print('filter')
            ufeed_entries = list(filter(self.query_in_entry, ufeed_entries))

        context['object_list'] = ufeed_entries

        paginator = Paginator(context['object_list'], 10)
        page = self.request.GET.get('page')

        try:
            context['object_list'] = paginator.page(page)
        except PageNotAnInteger:
            context['object_list'] = paginator.page(1)
        except EmptyPage:
            context['object_list'] = paginator.page(paginator.num_pages)

        object_list = context['object_list']

        if object_list.has_previous():
            prev_url = "?feed={}&page={}".format(feed_title, object_list.previous_page_number())
        else:
            prev_url = ''

        if object_list.has_next():
            next_url = "?feed={}&page={}".format(feed_title, object_list.next_page_number())
        else:
            next_url = ''

        context.update({
            'is_new': is_new,
            'is_paginated': True,
            'feed': ufeed,
            'next_url': next_url,
            'prev_url': prev_url,
            })
        return context

    def post(self, request):
        link = request.POST['new_rss']
        new_feed = models.Feed(link=link, user=request.user)
        try:
            new_feed.save()
        except KeyError:
            return render(request, 'errors/wrong_link.html', context={})
        return redirect('rss_reader:ufeeds_url')