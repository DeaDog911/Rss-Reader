from django.urls import path

from . import views

app_name = 'rss_reader'

urlpatterns = [
    # path('', views.index, name='ufeeds_url'),
    path('', views.FeedListView.as_view(), name='ufeeds_url'),
]