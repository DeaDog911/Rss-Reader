import re
import feedparser
import time
import random
from datetime import datetime
import time

from datetime import datetime

from . import models

def parse_feed(link):
    return feedparser.parse(link)

def remove_html(str):
    result = re.sub(r'\<[^>]*\>', '', str)
    return result

def get_feeds():
    feeds = [parse_feed(feed.link) for feed in models.Feed.objects.all()]

    #remove html code from description
    for feed in feeds:
        if feed.entries:
            for entry in feed.entries:
                entry.update({'description_without_html': remove_html(entry.description)})
                entry.update({'feed': feed.feed.title })

    return feeds

def transform_date(string):

    months = {
        'Jan' : "01",
        'Feb' : "02",
        'Mar' : "03",
        'Apr' : "04",
        'May' : "05",
        'Jun' : "06",
        'Jul' : "07",
        'Aug' : "08",
        'Sep' : "09",
        'Oct' : "10",
        'Nov' : "11",
        'Dec' : "12"
    }
    #remove weekday
    substrings = string.split(',')

    string = substrings[len(substrings) - 1].strip().split(' ')

    #replace months by numfg
    for i in range(0, len(string)):
        if string[i] in months:
            string[i] = months[string[i]]

    #collect date
    string = string[2]+"/"+string[1]+"/"+string[0] + ' ' + string[3]
    date = datetime.strptime(string, "%Y/%m/%d %H:%M:%S")
    return time.mktime(date.timetuple())

# def sort_feed(feed):
#     if feed:
#         for i in range(0, len(feed)):
#             for j in range(0, len(feed)):
#                 if transform_date(feed[i]['published']) > transform_date(feed[j]['published']):
#                     temp = feed[i]
#                     feed[i] = feed[j]
#                     feed[j] = temp
#     return feed

def quicksort(entries):
    if len(entries) <= 1:
        return entries
    else:
        q = random.choice(entries)
    l_nums = [entry for entry in entries if transform_date(entry['published']) < transform_date(q['published'])]
 
    e_nums = [q] * entries.count(q)
    b_nums = [entry for entry in entries if transform_date(entry['published']) > transform_date(q['published'])]
    # return quicksort(l_nums) + e_nums + quicksort(b_nums)
    return quicksort(b_nums) + e_nums + quicksort(l_nums) 

def get_new_entries():
    prestart_time = datetime.now()

    feed_new = []
    start_time = datetime.now()
    for feed in get_feeds():
        if feed.entries:
            feed_new += feed.entries
    print(f'хуета - {datetime.now() - prestart_time}')
    # feed_new = sort_feed(feed_new)
    feed_new = quicksort(feed_new)
    print(f'get_new_entries - {datetime.now() - prestart_time}')
    return feed_new