from django.apps import AppConfig


class RssReaderConfig(AppConfig):
    name = 'rss_reader'
