from django.contrib.auth.models import User

from django.db import models

from . import util


# Create your models here.
class Feed(models.Model):
    title = models.CharField(max_length=100, null=True, unique=True)
    link = models.URLField(db_index=True, unique=True)
    image = models.URLField(null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='feeds', null=True)

    def save(self, *args, **kwargs):
        if not self.id:
            feed = util.parse_feed(self.link)
            self.title = feed.feed['title']
            self.image = feed.feed['image']['link']
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title
