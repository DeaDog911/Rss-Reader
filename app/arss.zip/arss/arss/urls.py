from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls import handler404, handler500

from . import views

handler404 = views.e_handler404
handler500 = views.e_handler500

urlpatterns = [
    path('', views.landing, name="landing_url"),
    path('admin/', admin.site.urls),
    path('reader/', include('rss_reader.urls')),
    path('profile/', include('user_interaction.urls')),
    path('profile/', include('django.contrib.auth.urls')),
]