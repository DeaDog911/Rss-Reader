from django.shortcuts import redirect
from django.shortcuts import render

def landing(request):
    if request.user.is_authenticated:
        return redirect('/reader/')

    return render(request, 'landing.html', context={'dont_show_navbar': True})

def e_handler404(request, exception):
    return render(request, 'errors/e404.html', status=404)


def e_handler500(request):
    return render(request, 'errors/e500.html', status=500)
