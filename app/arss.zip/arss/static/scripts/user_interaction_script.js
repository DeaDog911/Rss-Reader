$(document).ready(function() {

    var csrftoken = $.cookie('csrftoken');

    function csrfSafeMethod(method) {
        // these HTTP methods do not require CSRF protection
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
    }

    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            }
        }
    });

    var feed_link = '';

    $('.delete-button').click(function() {
        var elem = event.target;
        event.preventDefault();
        feed_link = elem.parentElement.parentElement.parentElement.id;
        $.ajax({
            type: 'POST',
            url: 'delete_feed',
            data: {'feed': feed_link },
            success: function() {
                elem.parentElement.parentElement.parentElement.remove();
                var feed_count = $('#feeds-count');
                var feed_list = $('#feeds-list');
                feed_count.innerHTML = feed_list.children.length;
            }
        });

    });

    function show(elem) {
        elem.style.display = 'block';
    }

    function hide(elem) {
        elem.style.display = 'none';
    }

    var edit_block = null;
    var edit_button = null;

    $('.edit-button').click(function() {
        event.preventDefault();
        var elem = event.target;
        edit_button = elem;
        feed_link = elem.parentElement.parentElement.parentElement.id;
        edit_block = document.getElementById('edit-'+ feed_link);

        if (edit_block.style.display == 'none') {
            show(edit_block);
            elem.innerHTML = 'Cansel edit';
        }else {
            hide(edit_block);
            elem.innerHTML = 'Edit';
        }
    });

    $('.save-button').click(function() {
        event.preventDefault();
        var new_name = document.getElementById('new_name-' + feed_link).value;
        var new_link = document.getElementById('new_link-' + feed_link).value;
        $.ajax({
            type: 'POST',
            url: 'edit_feed',
            data: {
                'new_name': new_name,
                'new_link': new_link,
                'old_link': feed_link,
            },
            success: function() {
                hide(edit_block);
                var feed_name = document.getElementById('name-' + feed_link);
                feed_name.innerHTML = new_name;
                edit_button.innerHTML = "Edit";
            }
        });
    })

    var edit_btn = null;
    $('#edit-profile-btn').click(function() {
        event.preventDefault();
        edit_btn = event.target;
        var confirm_form = document.getElementById('confirm-form');

        if (confirm_form.style.display == 'none') {
            edit_btn.innerHTML = 'Cansel edit';
            show(confirm_form);
        }else {
            edit_btn.innerHTML = 'Edit';
            hide(confirm_form);
        }

    });


    $('#confirm-btn').click(function() {
        event.preventDefault();
        var elem = event.target;
        var pass = document.getElementById('pass').value;
        var new_username = document.getElementById('username_field').value;
        var new_email = document.getElementById('email_field').value;
        $.ajax({
            type: 'POST',
            url: 'edit',
            data: {
                'password': pass,
                'new_username': new_username,
                'new_email': new_email,
            },
            success: function(data) {
                if(data != 'Invalid password') {
                    hide(elem.parentElement);
                    edit_btn.innerHTML = "Edit";
                } else {
                    alert(data);
                }
            }

        });
    })

    $('#find-feed-btn').click((e) => {
        e.preventDefault();
        var new_feed_link = $('#new-feed-link').val();
        document.getElementById('spinner').style.display = 'block';
        $.ajax({
            type: 'POST',
            url: '',
            data: {
                'add': false,
                'user_request': new_feed_link
            },
            success: (data) => {
                document.getElementById('spinner').style.display = 'none';
                if(data != '') {
                    var found_feeds = document.getElementById('found-feeds');
                    if(data['results'].length == 0) {
                        found_feeds.textContent = '';
                        found_feeds.textContent = 'No results were found for your query';
                    }else {
                        found_feeds.textContent = '';
                    }
                    var feeds = data['results'];
                    feeds.forEach((feed) => {
                        var title = feed['title'];
                        var link = feed['feedId'].slice(5);
                        var description = feed['description'];
                        var item = document.createElement('div');
                        item.setAttribute('id', link)

                        var div = document.createElement('div');
                        div.setAttribute('class', 'upper-block');

                        var title_elem = document.createElement('p');
                        title_elem.innerHTML = title;
                        title_elem.setAttribute('class', 'found-feed-title');
                        div.appendChild(title_elem);


                        if (feed['iconUrl'] != undefined) {
                            var icon_elem = document.createElement('img');
                            icon_elem.setAttribute('src', feed['iconUrl']);
                            icon_elem.setAttribute('class', 'found-feed-icon');
                            div.appendChild(icon_elem);
                        }

                        var add_btn = document.createElement('button');
                        add_btn.innerHTML = 'Add';
                        add_btn.setAttribute('class', 'btn btn-success add-found-feed');
                        div.appendChild(add_btn);

                        item.appendChild(div);

                        var description_elem = document.createElement('p');
                        description_elem.innerHTML = description;
                        description_elem.setAttribute('class', 'found-feed-description')
                        item.appendChild(description_elem);

                        item.setAttribute('class', 'list-group-item');

                        $(item).on('click', '.add-found-feed', add_feed);

                        found_feeds.appendChild(item);
                    })
                }else {
                    window.location.reload();
                }
            }
        })
    })

    function add_feed(e) {
        console.log('hello');
        e.preventDefault();
        var target = e.target;
        var link = target.parentElement.parentElement.id;
        $.ajax({
            type: 'POST',
            url: '',
            data: {
                'add': true,
                'user_request': link,
            },
            success: (data) => {
                window.location.reload();
            }
        })
    }

    function isJson(data) {
        try {
            var t = data == ''
        } catch (e) {
            return true;
        }
        return false;
    }

});