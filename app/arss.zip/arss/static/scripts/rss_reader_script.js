function ajaxPagination() {
    $("#pagination a.page-link").each((index, el) => {
        $(el).click((e) => {
            e.preventDefault();
            var page_url = $(el).attr('href');

            $.ajax({
                url: page_url,
                type: 'GET',
                success: (data) => {
                    $('#feed').empty();
                    $('#feed').append( $(data).find('#feed').html() );
                    $('#pagination').empty();
                    $('#pagination').append( $(data).find('#pagination').html() );
                }                
            })
        })
    })
}

$(document).ready(function() {
    ajaxPagination();
})

$(document).ajaxStop(function() {
    ajaxPagination();
    console.log('stop');
})