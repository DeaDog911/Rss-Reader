// var csrftoken = $.cookie('csrftoken');

//     function csrfSafeMethod(method) {
//         // these HTTP methods do not require CSRF protection
//         return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
//     }

//     $.ajaxSetup({
//         beforeSend: function(xhr, settings) {
//             if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
//                 xhr.setRequestHeader("X-CSRFToken", csrftoken);
//             }
//         }
//     });


// var img = document.getElementById('message-img')
// var message_block = document.getElementById('message-block');

// img.onclick = (e) => {
//     if (get_elem_display(message_block) != 'block')
//         message_block.style.display = 'block';
//     else 
//         message_block.style.display = 'none';
// }

// function get_elem_display(elem) {
//     return elem.style.display;
// }

// $("#send-message-btn").click((e) => {
//     e.preventDefault();

//     var email = $('#email').val();
//     var subject = $('#subject').val();
//     var message = $('#message').val();

//     $.ajax({
//         url: '/profile/send_message',
//         type: 'POST', 
//         data: {
//             'email': email,
//             'subject': subject,
//             'message': message,
//         },
//         success: (data) => {
//             if(data == '') 
//                 message_block.style.display = 'none';
//             else 
//                 alert(data);
//         }
//     })
// })
