
css_dir = "css" # by Compass.app 
sass_dir = "scss" # by Compass.app 
images_dir = "" # by Compass.app 
output_style = :expanded # by Compass.app 
relative_assets = false # by Compass.app 
line_comments = true # by Compass.app 
sass_options = {:debug_info=>false} # by Compass.app 
sourcemap = false # by Compass.app 